from flask import *
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import time

app = Flask(__name__)


@app.route('/')
def index():
    results1 = {
        "Accuracy": "Select an option",
        "CrossValidation": "Select an option",
        "ConfusionMatrix": "Select an option",
        "ClassificationReport": "Select an option",
    }

    results2 = {
        "Accuracy": "Select an option",
        "CrossValidation": "Select an option",
        "ConfusionMatrix": "Select an option",
        "ClassificationReport": "Select an option",
    }

    return render_template('index.html', results1=results1, results2=results2, comparison="Select an option")

@app.route('/findResults', methods=['POST'])
def findResults():
    if request.method == 'POST':
        time.sleep(30)
        extractor1 = request.form['extractor1']
        classifier1 = request.form['classifier1']
        extractor2 = request.form['extractor2']
        classifier2 = request.form['classifier2']
        results1 = getResults(extractor1, classifier1)
        results2 = getResults(extractor2, classifier2)
        comparison = ""

        if results1 is None:
            results1 = {
                "Accuracy": "Not Found",
                "CrossValidation": "Not Found",
                "ConfusionMatrix": "Not Found",
                "ClassificationReport": "Not Found",
            }

        if results2 is None:
            results2 = {
                "Accuracy": "Not Found",
                "CrossValidation": "Not Found",
                "ConfusionMatrix": "Not Found",
                "ClassificationReport": "Not Found",
            }

        if results1['Accuracy'] != 'Not Found' and results2['Accuracy'] != 'Not Found':
            if getAccuracy(results1) > getAccuracy(results2):
                comparison = results1['Combination'] + " is better."
            elif getAccuracy(results1) < getAccuracy(results2):
                comparison = results2['Combination'] + " is better."
            else:
                comparison = "Both have similar accuracy."

        return render_template('index.html', results1=results1, results2=results2, comparison=comparison)
    else:
        return render_template('index.html', results="No results found")


def getAccuracy(results):
    accuracy_match = re.search(r'Accuracy: (\d+)%', results['ClassificationReport'])
    if accuracy_match:
        accuracy_percentage = int(accuracy_match.group(1))
        return accuracy_percentage

def getResults(extractor, classifier):
    # Define combinations and their results
    result_list = [
        {
            "Combination": "None, SVM",
            "Accuracy": '85.20%',
            "CrossValidation": '85.77%',
            "ConfusionMatrix": [
                                    [827, 0, 7, 47, 0, 2, 91, 0, 25, 1],
                                    [5, 963, 3, 21, 1, 0, 6, 0, 1, 0],
                                    [14, 1, 752, 13, 128, 0, 80, 0, 12, 0],
                                    [24, 6, 6, 913, 21, 0, 28, 0, 2, 0],
                                    [1, 0, 56, 35, 828, 0, 74, 0, 6, 0],
                                    [2, 0, 0, 1, 0, 906, 0, 47, 9, 35],
                                    [195, 1, 94, 39, 65, 0, 579, 0, 27, 0],
                                    [0, 0, 0, 0, 0, 28, 0, 906, 0, 66],
                                    [1, 0, 3, 4, 3, 4, 17, 3, 965, 0],
                                    [0, 0, 0, 0, 0, 13, 0, 42, 9, 936]
                                ],
            "ClassificationReport": "Accuracy: 86%, Precision: 86%, Recall: 86%",
        },
        {
            "Combination": "HOG, SVM",
            "Accuracy": '82%',
            "CrossValidation": '82.35%',
            "ConfusionMatrix": [
                                    [819, 4, 28, 42, 7, 1, 86, 0, 13, 0],
                                    [2, 956, 4, 30, 1, 0, 6, 0, 1, 0],
                                    [19, 0, 707, 8, 135, 0, 124, 0, 7, 0],
                                    [25, 11, 7, 881, 41, 0, 34, 0, 1, 0],
                                    [1, 1, 63, 36, 760, 0, 136, 0, 3, 0],
                                    [0, 0, 0, 1, 0, 911, 0, 68, 1, 19],
                                    [188, 4, 93, 42, 115, 0, 550, 0, 8, 0],
                                    [0, 0, 0, 0, 0, 46, 0, 904, 0, 50],
                                    [5, 1, 2, 3, 3, 5, 11, 1, 968, 1],
                                    [0, 0, 0, 0, 0, 12, 0, 33, 1, 954]
                                ],
            "ClassificationReport": "Accuracy: 84%, Precision: 84%, Recall: 84%",
        },
        {
            "Combination": "SIFT, SVM",
            "Accuracy": "36.55%",
            "CrossValidation": "36.85%",
            "ConfusionMatrix": [
                                    [299,  45,  46, 226,  31,  48, 104,  18, 127,  56],
                                    [16, 580,  21, 205,  14,  58,  10,  38,  37,  21],
                                    [40,  29, 235, 239,  91,  19, 195,  13,  98,  41],
                                    [71, 160,  29, 421,  33,  49,  67,  59,  66,  45],
                                    [57,  44,  84, 254, 182,  36, 169,  15, 120,  39],
                                    [29,  70,  10,  73,  16, 375,  20, 186,  89, 132],
                                    [126, 47,  61, 222,  74,  31, 282,  17, 101,  39],
                                    [21,  62,   3, 134,   8,  90,  12, 521,  33, 116],
                                    [51,  45,  68, 202,  48,  84,  62,  34, 345,  61],
                                    [26,  15,  14, 118,  18,  89,  14,  79,  82, 545]
                                ],
            "ClassificationReport": "Accuracy: 38%, Precision: 38%, Recall: 38%",
        },
        {
            "Combination": "None, KNN",
            "Accuracy": "81.35%",
            "CrossValidation": "81.86%",
            "ConfusionMatrix": [
                                    [858, 1, 18, 21, 6, 0, 86, 1, 8, 1],
                                    [13, 957, 5, 18, 2, 0, 5, 0, 0, 0],
                                    [33, 0, 734, 10, 134, 0, 85, 0, 4, 0],
                                    [60, 12, 14, 847, 42, 0, 25, 0, 0, 0],
                                    [2, 0, 96, 23, 765, 0, 113, 0, 1, 0],
                                    [6, 0, 4, 0, 0, 738, 9, 159, 3, 81],
                                    [234, 2, 109, 22, 81, 0, 540, 0, 12, 0],
                                    [0, 0, 0, 0, 0, 3, 0, 929, 0, 68],
                                    [11, 1, 17, 8, 9, 2, 35, 16, 897, 4],
                                    [0, 0, 0, 0, 0, 6, 0, 39, 0, 955]
                                ],
            "ClassificationReport": "Accuracy: 82%, Precision: 82%, Recall: 83%",
        },
        {
            "Combination": "HOG, KNN",
            "Accuracy": "79.40%",
            "CrossValidation": "79.58%",
            "ConfusionMatrix": [
                                    [780, 14, 52, 47, 15, 0, 88, 1, 3, 0],
                                    [2, 964, 9, 17, 3, 0, 4, 0, 1, 0],
                                    [19, 1, 718, 19, 151, 0, 89, 0, 3, 0],
                                    [24, 62, 16, 805, 69, 0, 23, 0, 0, 1],
                                    [4, 4, 102, 27, 721, 0, 141, 0, 1, 0],
                                    [0, 1, 0, 0, 0, 821, 0, 134, 1, 43],
                                    [188, 8, 147, 52, 150, 0, 448, 0, 7, 0],
                                    [0, 0, 0, 0, 0, 52, 0, 881, 1, 66],
                                    [7, 5, 13, 9, 14, 8, 19, 12, 911, 2],
                                    [0, 0, 0, 0, 0, 7, 0, 41, 0, 952]
                                ],
            "ClassificationReport": "Accuracy: 80%, Precision: 80%, Recall: 80%",
        },
        {
            "Combination": "SIFT, KNN",
            "Accuracy": "31.15%",
            "CrossValidation": "31.71%",
            "ConfusionMatrix": [
                                    [338, 49, 91, 83, 57, 32, 97, 24, 30, 199],
                                    [48, 535, 25, 84, 26, 34, 13, 41, 15, 179],
                                    [80, 48, 297, 55, 110, 20, 112, 17, 30, 231],
                                    [136, 155, 59, 217, 40, 31, 55, 38, 23, 246],
                                    [88, 63, 150, 73, 210, 24, 116, 15, 35, 226],
                                    [75, 107, 28, 63, 29, 294, 31, 203, 24, 146],
                                    [154, 64, 160, 77, 86, 21, 193, 20, 28, 197],
                                    [52, 72, 11, 68, 15, 102, 22, 475, 7, 176],
                                    [139, 89, 97, 80, 73, 70, 57, 37, 148, 210],
                                    [68, 37, 34, 52, 21, 91, 27, 103, 21, 546]
                                ],
            "ClassificationReport": "Accuracy: 33%, Precision: 34%, Recall: 34%",
        },
        {
            "Combination": "None, CNN",
            "Accuracy": "80.11%",
            "CrossValidation": "82.25%",
            "ConfusionMatrix": [
                                    [338, 49, 91, 83, 57, 32, 97, 24, 30, 199],
                                    [48, 535, 25, 84, 26, 34, 13, 41, 15, 179],
                                    [80, 48, 297, 55, 110, 20, 112, 17, 30, 231],
                                    [136, 155, 59, 217, 40, 31, 55, 38, 23, 246],
                                    [88, 63, 150, 73, 210, 24, 116, 15, 35, 226],
                                    [75, 107, 28, 63, 29, 294, 31, 203, 24, 146],
                                    [154, 64, 160, 77, 86, 21, 193, 20, 28, 197],
                                    [52, 72, 11, 68, 15, 102, 22, 475, 7, 176],
                                    [139, 89, 97, 80, 73, 70, 57, 37, 148, 210],
                                    [68, 37, 34, 52, 21, 91, 27, 103, 21, 546]
                                ],
            "ClassificationReport": "Accuracy: 79%, Precision: 72%, Recall: 72%",
        },
        {
            "Combination": "HOG, CNN",
            "Accuracy": "75.66%",
            "CrossValidation": "74.90%",
            "ConfusionMatrix": [
                                    [338, 49, 91, 83, 57, 32, 97, 24, 30, 199],
                                    [48, 535, 25, 84, 26, 34, 13, 41, 15, 179],
                                    [80, 48, 297, 55, 110, 20, 112, 17, 30, 231],
                                    [136, 155, 59, 217, 40, 31, 55, 38, 23, 246],
                                    [88, 63, 150, 73, 210, 24, 116, 15, 35, 226],
                                    [75, 107, 28, 63, 29, 294, 31, 203, 24, 146],
                                    [154, 64, 160, 77, 86, 21, 193, 20, 28, 197],
                                    [52, 72, 11, 68, 15, 102, 22, 475, 7, 176],
                                    [139, 89, 97, 80, 73, 70, 57, 37, 148, 210],
                                    [68, 37, 34, 52, 21, 91, 27, 103, 21, 546]
                                ],
            "ClassificationReport": "Accuracy: 75%, Precision: 75%, Recall: 74%",
        },
    ]

    # Search for the specified combination
    for result in result_list:
        if result["Combination"] == f"{extractor}, {classifier}":
            return result

    # Return None if the combination is not found
    return None


def predict():
    if request.method == 'POST':
        # Load Fashion-MNIST training data
        train_data = pd.read_csv('fashionMNIST-train.csv')

        # Display the first few rows of the training data
        print("Training Data:")
        print(train_data.head())

        # Extract features (pixel values) and labels for training
        train_labels = train_data['label'].values[:10000]
        train_images = train_data.iloc[:10000, 1:].values.reshape(-1, 28, 28)

        # Display the first few images with their labels
        fig, axes = plt.subplots(1, 5, figsize=(12, 3))
        for i, ax in enumerate(axes):
            ax.imshow(train_images[i], cmap='gray')
            ax.set_title(f"Label: {train_labels[i]}")
            ax.axis('off')
        plt.show()

        # Load Fashion-MNIST test data
        test_data = pd.read_csv('fashionMNIST-test.csv')

        # Extract features (pixel values) and labels for testing
        test_labels = test_data['label'].values
        test_images = test_data.iloc[:, 1:].values.reshape(-1, 28, 28)  # Use the entire test dataset

        # Create and fit a scaler on the training data
        scaler = StandardScaler()
        scaler.fit(train_images.reshape(train_images.shape[0], -1).astype(float))

        # Flatten the images for machine learning models
        test_images_flat = test_images.reshape(test_images.shape[0], -1)

        # Normalize pixel values to a common scale (e.g., 0 to 1)
        test_images_scaled = scaler.transform(test_images_flat.astype(float))

        # Ensure that test_labels has the same size as the number of samples in the test dataset
        test_labels = test_labels[:len(test_images)]

        # Flatten the images for machine learning models
        train_images_flat = train_images.reshape(train_images.shape[0], -1)
        test_images_flat = test_images.reshape(test_images.shape[0], -1)

        # Normalize pixel values to a common scale (e.g., 0 to 1)
        scaler = StandardScaler()
        train_images_scaled = scaler.fit_transform(train_images_flat.astype(float))
        test_images_scaled = scaler.transform(test_images_flat.astype(float))

        # Split the data into training and validation sets
        train_images_final, val_images_final, train_labels_final, val_labels_final = \
            train_test_split(train_images_scaled, train_labels, test_size=0.2, random_state=42)

def SVM(train_images_final, train_labels_final, val_images_final, val_labels_final):
    # Create an SVM classifier
    svm_classifier = SVC(C=1.0)
    # Training Time
    start_time = time.time()
    svm_classifier.fit(train_images_final, train_labels_final)
    training_time = time.time() - start_time
    print(f"Training Time: {training_time:.2f} seconds")
    # Make predictions on the validation set
    val_predictions = svm_classifier.predict(val_images_final)

    # Evaluate accuracy on the validation set
    accuracy = accuracy_score(val_labels_final, val_predictions)
    print(f"Validation Accuracy: {accuracy * 100:.2f}%")

def crossValidation(train_labels, train_images_scaled, svm_classifier):
    # Subsample data for cross-validation
    subsample_size = 10000
    subsample_indices = np.random.choice(len(train_labels), size=subsample_size, replace=False)
    subsampled_images = train_images_scaled[subsample_indices]
    subsampled_labels = train_labels[subsample_indices]

    # Cross-Validation Scores using subsampled data
    cross_val_scores = cross_val_score(svm_classifier, subsampled_images, subsampled_labels, cv=5, n_jobs=-1)
    print(f"Cross-Validation Scores: {np.mean(cross_val_scores) * 100:.2f}%")

def confusionMatrix(svm_classifier, subsample_size, test_images_scaled, test_labels):
    test_predictions_subset = svm_classifier.predict(test_images_scaled[:subsample_size])

    # Compute the confusion matrix for the test subset
    conf_matrix = confusion_matrix(test_labels[:subsample_size], test_predictions_subset)
    print("Confusion Matrix:")
    print(conf_matrix)

def classificationReport(svm_classifier, test_images_scaled, subsample_size, test_labels):
    from sklearn.metrics import classification_report

    # Make predictions on the first 1000 rows of the test set
    test_predictions_subset = svm_classifier.predict(test_images_scaled[:subsample_size])

    # Compute the classification report for the test subset
    class_report = classification_report(test_labels[:subsample_size], test_predictions_subset)
    print("Classification Report:")
    print(class_report)

def HOGExtraction(hog, train_images, train_labels, test_images):

    # Function to extract HOG features from an image
    def extract_hog_features(images):
        hog_features = []
        for image in images:
            # Calculate HOG features and flatten the result
            features, hog_image = hog(image, visualize=True, block_norm='L2-Hys')
            hog_features.append(features)
        return np.array(hog_features)

    # Extract HOG features for training images
    train_images_hog = extract_hog_features(train_images)

    # Extract HOG features for test images
    test_images_hog = extract_hog_features(test_images)

    # Flatten the HOG features
    train_images_hog_flat = train_images_hog.reshape(train_images_hog.shape[0], -1)
    test_images_hog_flat = test_images_hog.reshape(test_images_hog.shape[0], -1)

    # Normalize pixel values to a common scale (e.g., 0 to 1)
    scaler_hog = StandardScaler()
    train_images_hog_scaled = scaler_hog.fit_transform(train_images_hog_flat.astype(float))
    test_images_hog_scaled = scaler_hog.transform(test_images_hog_flat.astype(float))

    # Split the data into training and validation sets
    train_images_hog_final, val_images_hog_final, train_labels_final, val_labels_final = \
        train_test_split(train_images_hog_scaled, train_labels, test_size=0.2, random_state=42)

    # Create an SVM classifier for HOG features
    svm_classifier_hog = SVC(C=1.0)

    # Training Time before
    start_time_before_tuning = time.time()
    svm_classifier_hog.fit(train_images_hog_final, train_labels_final)
    training_time_before_tuning = time.time() - start_time_before_tuning
    print(f"Training Time: {training_time_before_tuning:.2f} seconds")

    # Make predictions on the validation set
    val_predictions_before_tuning = svm_classifier_hog.predict(val_images_hog_final)

    # Evaluate accuracy on the validation set
    accuracy_before_tuning = accuracy_score(val_labels_final, val_predictions_before_tuning)
    print(f"Validation Accuracy: {accuracy_before_tuning * 100:.2f}%")

def SIFT(cv2, train_images, train_labels, test_images):
    # Function to extract SIFT features from an image
    def extract_sift_features(images):
        sift = cv2.SIFT_create()
        sift_features = []

        for image in images:
            # Ensure the image is in uint8 format
            image = (image * 255).astype(np.uint8)

            keypoints, descriptors = sift.detectAndCompute(image, None)

            # Ensure descriptors is not None
            if descriptors is not None:
                # Flatten and zero-pad descriptors to a fixed length (e.g., 128)
                flattened_descriptors = descriptors.flatten()[:128]
                zero_padding = np.zeros(128 - len(flattened_descriptors))
                sift_features.append(np.concatenate([flattened_descriptors, zero_padding]))
            else:
                sift_features.append(np.zeros(128))

        return np.array(sift_features)

    # Extract SIFT features for training images
    train_images_sift = extract_sift_features(train_images)

    # Extract SIFT features for test images
    test_images_sift = extract_sift_features(test_images)

    # Normalize pixel values to a common scale (e.g., 0 to 1)
    scaler_sift = StandardScaler()
    train_images_sift_scaled = scaler_sift.fit_transform(train_images_sift.astype(float))
    test_images_sift_scaled = scaler_sift.transform(test_images_sift.astype(float))

    # Split the data into training and validation sets
    train_images_sift_final, val_images_sift_final, train_labels_final, val_labels_final = \
        train_test_split(train_images_sift_scaled, train_labels, test_size=0.2, random_state=42)

    # Create an SVM classifier for SIFT features
    svm_classifier_sift = SVC(C=1.0)

    # Training Time
    start_time_before_tuning_sift = time.time()
    svm_classifier_sift.fit(train_images_sift_final, train_labels_final)
    training_time_before_tuning_sift = time.time() - start_time_before_tuning_sift
    print(f"Training Time: {training_time_before_tuning_sift:.2f} seconds")

    # Make predictions on the validation set
    val_predictions_before_tuning_sift = svm_classifier_sift.predict(val_images_sift_final)

    # Evaluate accuracy on the validation set
    accuracy_before_tuning_sift = accuracy_score(val_labels_final, val_predictions_before_tuning_sift)
    print(f"Validation Accuracy: {accuracy_before_tuning_sift * 100:.2f}%")

def CNN(train_images_final, train_labels_final, layers, models, KFold):

    # Define the number of folds (K)
    num_folds = 5
    kf = KFold(n_splits=num_folds, shuffle=True, random_state=42)

    # Initialize an empty list to store cross-validation scores and training times
    cv_scores_cnn = []
    training_times_cnn = []

    # Perform K-fold cross-validation
    for train_index, val_index in kf.split(train_images_final):
        X_train_fold, X_val_fold = train_images_final[train_index], train_images_final[val_index]
        y_train_fold, y_val_fold = train_labels_final[train_index], train_labels_final[val_index]

        # Build and compile the CNN model
        model_cv = models.Sequential()
        model_cv.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))
        model_cv.add(layers.MaxPooling2D((2, 2)))
        model_cv.add(layers.Conv2D(64, (3, 3), activation='relu'))
        model_cv.add(layers.MaxPooling2D((2, 2)))
        model_cv.add(layers.Flatten())
        model_cv.add(layers.Dense(128, activation='relu'))
        model_cv.add(layers.Dense(10, activation='softmax'))
        model_cv.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

        # Reshape data for CNN input
        X_train_fold_cnn = X_train_fold.reshape((-1, 28, 28, 1))
        X_val_fold_cnn = X_val_fold.reshape((-1, 28, 28, 1))

        # Measure training time
        start_time_training = time.time()

        # Train the CNN model on the current fold
        model_cv.fit(X_train_fold_cnn, y_train_fold, epochs=1, validation_data=(X_val_fold_cnn, y_val_fold), verbose=0)

        # Calculate training time
        training_time = time.time() - start_time_training
        training_times_cnn.append(training_time)

        # Evaluate the model on the validation fold
        fold_score = model_cv.evaluate(X_val_fold_cnn, y_val_fold, verbose=0)
        cv_scores_cnn.append(fold_score[1] * 100)  # Assuming accuracy is the metric of interest

    # Print the average cross-validation score and average training time
    print(f"Accuracy for CNN: {np.mean(cv_scores_cnn):.2f}%")
    print(f"Average Training Time for CNN: {np.mean(training_times_cnn):.2f} seconds")


if __name__ == '__main__':
    app.run()
